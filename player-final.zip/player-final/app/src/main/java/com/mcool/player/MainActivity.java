package com.mcool.player;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.provider.MediaStore;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "MusicPlayerPrefs";
    private static final String KEY_SONG_LIST_CACHE = "song_list_cache";
    private static final String KEY_LAST_SCAN_PATH = "last_scan_path";

    private List<MusicBean> songList;
    private RecyclerView recyclerView;
    private MusicAdapter adapter;
    private MusicService musicService;
    private Intent playIntent;
    private boolean musicBound = false;

    // UI Controls
    private TextView tvSongTitle, tvArtistAlbum, tvCurrentTime, tvTotalTime;
    private TextView tvPlayMode, tvNextSong; // Play mode and next song info
    private ImageButton btnPrev, btnPlayPause, btnNext, btnMode;
    private Button btnScan, btnRefresh, btnExit;
    private SeekBar seekBar;
    private ImageView ivBackground, ivAlbumCover;
    private HorizontalLyricsView horizontalLyricsView;
    private LyricsView lyricsView; // Vertical lyrics view
    
    // Tab related
    private Button btnTabSongList, btnTabPlayer;
    private View songListView, playerView;
    private int currentTab = 0; // 0 = Song List, 1 = Player
    
    // Song list related
    private RecyclerView rvSongList;
    private SongListAdapter songListAdapter;
    private List<MusicBean> filteredSongList = new ArrayList<>();
    private android.widget.EditText etSearch;

    private android.util.LruCache<String, android.graphics.Bitmap> mCoverCache;
    private android.util.LruCache<String, List<HorizontalLyricsView.LyricLine>> mLyricsCache;
    private android.util.LruCache<String, MetadataInfo> mMetadataCache;

    // Simple metadata holder class
    private static class MetadataInfo {
        String title;
        String artist;
        String album;
        
        MetadataInfo(String title, String artist, String album) {
            this.title = title;
            this.artist = artist;
            this.album = album;
        }
    }

    private Handler handler = new Handler();
    private Runnable updateTask = new Runnable() {
        @Override
        public void run() {
            if (musicService != null && musicBound && musicService.isPng()) {
                long pos = musicService.getPosn();
                int dur = musicService.getDur();
                
                // Update horizontal lyrics
                if (horizontalLyricsView != null) {
                    horizontalLyricsView.updateTime(pos);
                }
                
                // Update vertical lyrics
                if (lyricsView != null) {
                    lyricsView.updateTime(pos);
                }
                
                // Update SeekBar
                if (dur > 0) {
                    int progress = (int) ((pos * 100) / dur);
                    seekBar.setProgress(progress);
                }
                
                // Update time labels
                if (tvCurrentTime != null) tvCurrentTime.setText(formatTime(pos));
                if (tvTotalTime != null) {
                    long remaining = dur - pos;
                    tvTotalTime.setText("-" + formatTime(remaining));
                }
            }
            handler.postDelayed(this, 500);
        }
    };
    
    private BroadcastReceiver updateUIReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            updateUI();
        }
    };

    private ServiceConnection musicConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.MusicBinder binder = (MusicService.MusicBinder) service;
            musicService = binder.getService();
            if (songList != null) {
                musicService.setPlaylist(songList);
            }
            musicBound = true;
            Toast.makeText(MainActivity.this, "Service Connected", Toast.LENGTH_SHORT).show();
            updateUI();
            // Initialize play mode text after service is connected
            updateModeText(musicService.getPlayMode());
            // Initialize next song info
            updateNextSongInfo();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            musicBound = false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Initialize caches
        int maxMemory = (int) (Runtime.getRuntime().maxMemory() / 1024);
        int cacheSize = maxMemory / 8; // Use 1/8th of available memory for covers
        
        mCoverCache = new android.util.LruCache<String, android.graphics.Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, android.graphics.Bitmap bitmap) {
                return bitmap.getByteCount() / 1024;
            }
        };
        
        // Lyrics cache (smaller, count based)
        mLyricsCache = new android.util.LruCache<>(50); // Cache 50 songs' lyrics
        
        // Metadata cache (title, artist, album)
        mMetadataCache = new android.util.LruCache<>(100); // Cache 100 songs' metadata
        
        try {
            setContentView(R.layout.activity_main_tabs);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Layout error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }
        
        try {
            songList = new ArrayList<>();
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        try {
            playIntent = new Intent(this, MusicService.class);
            startService(playIntent);
            bindService(playIntent, musicConnection, Context.BIND_AUTO_CREATE);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Service error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }

        try {
            initTabViews();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Init views error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }
        
        // Temporarily disable cache loading to test
        // loadCachedSongList();
        
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
                } else {
                    loadMusic(null);
                }
            } else {
                // Android 4.4 doesn't need runtime permission
                loadMusic(null);
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Permission error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    
    /**
     * Initialize Tab views and setup tab switching
     */
    private void initTabViews() {
        // Find tab buttons
        btnTabSongList = findViewById(R.id.btnTabSongList);
        btnTabPlayer = findViewById(R.id.btnTabPlayer);
        Button btnExitApp = findViewById(R.id.btnExitApp);
        
        // Inflate and add views to container
        LayoutInflater inflater = LayoutInflater.from(this);
        ViewGroup contentContainer = findViewById(R.id.contentContainer);
        
        // Inflate song list view
        songListView = inflater.inflate(R.layout.fragment_song_list, contentContainer, false);
        contentContainer.addView(songListView);
        
        // Inflate player view
        playerView = inflater.inflate(R.layout.fragment_player, contentContainer, false);
        contentContainer.addView(playerView);
        
        // Setup tab click listeners
        btnTabSongList.setOnClickListener(v -> switchToTab(0));
        btnTabPlayer.setOnClickListener(v -> switchToTab(1));
        
        // Setup exit button
        btnExitApp.setOnClickListener(v -> {
            // Stop playback
            if (musicService != null && musicBound) {
                musicService.pausePlayer();
                musicService.stopSelf();
            }
            
            // Remove callbacks
            handler.removeCallbacks(updateTask);
            
            // Unbind service
            if (musicBound) {
                try {
                    unbindService(musicConnection);
                    musicBound = false;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            
            // Stop the service intent
            if (playIntent != null) {
                stopService(playIntent);
            }
            
            // Exit app
            finish();
            System.exit(0);
        });
        
        // Initialize song list tab
        initSongListTab();
        
        // Initialize player tab
        initPlayerTab();
        
        // Show song list tab by default
        switchToTab(0);
    }
    
    /**
     * Switch between tabs
     */
    private void switchToTab(int tab) {
        currentTab = tab;
        
        if (tab == 0) {
            // Show song list
            songListView.setVisibility(View.VISIBLE);
            playerView.setVisibility(View.GONE);
            btnTabSongList.setBackgroundColor(0xFF333333);
            btnTabPlayer.setBackgroundColor(0xFF444444);
        } else {
            // Show player
            songListView.setVisibility(View.GONE);
            playerView.setVisibility(View.VISIBLE);
            btnTabSongList.setBackgroundColor(0xFF444444);
            btnTabPlayer.setBackgroundColor(0xFF333333);
        }
    }
    
    /**
     * Initialize song list tab
     */
    private void initSongListTab() {
        rvSongList = songListView.findViewById(R.id.rvSongList);
        Button btnRandomPlay = songListView.findViewById(R.id.btnRandomPlay);
        Button btnScanList = songListView.findViewById(R.id.btnScanList);
        Button btnRefreshList = songListView.findViewById(R.id.btnRefreshList);
        etSearch = songListView.findViewById(R.id.etSearch);
        
        // Setup RecyclerView
        rvSongList.setLayoutManager(new LinearLayoutManager(this));
        songListAdapter = new SongListAdapter(this, filteredSongList);
        rvSongList.setAdapter(songListAdapter);
        
        // Scan button - open file picker
        btnScanList.setOnClickListener(v -> {
            new FilePickerDialog(this, file -> {
                loadMusic(file);
            }).show();
        });
        
        // Long press to show mount points info
        btnScanList.setOnLongClickListener(v -> {
            showMountPointsInfo();
            return true;
        });
        
        // Refresh button - reload from last scan path
        btnRefreshList.setOnClickListener(v -> {
            Toast.makeText(this, "刷新歌曲列表...", Toast.LENGTH_SHORT).show();
            String lastPath = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                    .getString(KEY_LAST_SCAN_PATH, null);
            if (lastPath != null) {
                loadMusic(new File(lastPath));
            } else {
                loadMusic(null);
            }
        });
        
        // Random play button
        btnRandomPlay.setOnClickListener(v -> {
            if (songList != null && !songList.isEmpty()) {
                // Shuffle the list
                List<MusicBean> shuffled = new ArrayList<>(songList);
                Collections.shuffle(shuffled);
                
                // Update service playlist
                if (musicService != null) {
                    musicService.setPlaylist(shuffled);
                    musicService.playSong(0);
                }
                
                // Switch to player tab
                switchToTab(1);
                
                Toast.makeText(this, "随机播放已启动", Toast.LENGTH_SHORT).show();
            }
        });
        
        // Search functionality
        etSearch.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterSongList(s.toString());
            }
            
            @Override
            public void afterTextChanged(android.text.Editable s) {}
        });
    }
    
    /**
     * Filter song list based on search query
     */
    private void filterSongList(String query) {
        filteredSongList.clear();
        
        if (query == null || query.trim().isEmpty()) {
            // Show all songs
            filteredSongList.addAll(songList);
        } else {
            // Filter by title (case insensitive)
            String lowerQuery = query.toLowerCase();
            for (MusicBean song : songList) {
                if (song.title.toLowerCase().contains(lowerQuery)) {
                    filteredSongList.add(song);
                }
            }
        }
        
        // Sort A-Z
        Collections.sort(filteredSongList, (a, b) -> a.title.compareToIgnoreCase(b.title));
        
        // Notify adapter
        if (songListAdapter != null) {
            songListAdapter.notifyDataSetChanged();
        }
    }
    
    /**
     * Initialize player tab (same as old initViews)
     */
    private void initPlayerTab() {
        // Find all player views from playerView
        tvSongTitle = playerView.findViewById(R.id.tvSongTitle);
        tvArtistAlbum = playerView.findViewById(R.id.tvArtistAlbum);
        // horizontalLyricsView has been removed from layout
        horizontalLyricsView = playerView.findViewById(R.id.horizontalLyricsView);  // Will be null
        lyricsView = playerView.findViewById(R.id.lyricsView);
        seekBar = playerView.findViewById(R.id.seekBar);
        ivBackground = playerView.findViewById(R.id.ivBackground);
        ivAlbumCover = playerView.findViewById(R.id.ivAlbumCover);
        tvCurrentTime = playerView.findViewById(R.id.tvCurrentTime);
        tvTotalTime = playerView.findViewById(R.id.tvTotalTime);
        tvPlayMode = playerView.findViewById(R.id.tvPlayMode);
        tvNextSong = playerView.findViewById(R.id.tvNextSong);
        
        btnPrev = playerView.findViewById(R.id.btnPrev);
        btnPlayPause = playerView.findViewById(R.id.btnPlayPause);
        btnNext = playerView.findViewById(R.id.btnNext);
        btnMode = playerView.findViewById(R.id.btnMode);  // Will be null (removed from layout)
        btnExit = playerView.findViewById(R.id.btnExit);
        
        // Setup play mode text click listener
        if (tvPlayMode != null) {
            tvPlayMode.setOnClickListener(v -> {
                if (musicService != null) {
                    // Cycle through play modes
                    int currentMode = musicService.getPlayMode();
                    int nextMode = (currentMode + 1) % 3; // 0->1->2->0
                    musicService.setPlayMode(nextMode);
                    updateModeText(nextMode);
                }
            });
        }
        
        // Setup all button listeners (same as old initViews)
        setupPlayerControls();
        
        // Initialize play mode text
        if (musicService != null) {
            updateModeText(musicService.getPlayMode());
        }
    }
    
    /**
     * Setup player control buttons
     */
    private void setupPlayerControls() {
        // Exit button
        btnExit.setOnClickListener(v -> {
            if (musicService != null && musicBound) {
                musicService.pausePlayer();
                musicService.stopSelf();
            }
            handler.removeCallbacks(updateTask);
            if (musicBound) {
                try {
                    unbindService(musicConnection);
                    musicBound = false;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (playIntent != null) {
                stopService(playIntent);
            }
            finish();
            System.exit(0);
        });
        
        // Previous button
        btnPrev.setOnClickListener(v -> {
            if (musicService != null) musicService.playPrev();
        });
        
        // Next button
        btnNext.setOnClickListener(v -> {
            if (musicService != null) musicService.playNext();
        });
        
        // Play/Pause button
        btnPlayPause.setOnClickListener(v -> {
            if (musicService != null) {
                if (musicService.isPng()) {
                    musicService.pausePlayer();
                    btnPlayPause.setImageResource(R.drawable.play);
                } else {
                    musicService.resumePlayer();
                    btnPlayPause.setImageResource(R.drawable.pause);
                }
            }
        });
        
        // Mode button (now using text button, but keep for compatibility)
        if (btnMode != null) {
            btnMode.setOnClickListener(v -> {
                if (musicService != null) {
                    int mode = musicService.getPlayMode();
                    mode = (mode + 1) % 3;
                    musicService.setPlayMode(mode);
                    updateModeButton(mode);
                }
            });
        }
        
        // SeekBar
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && musicService != null) {
                    int dur = musicService.getDur();
                    long newPos = (long) ((progress / 100.0) * dur);
                    musicService.seek((int) newPos);
                }
            }
            
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    private void initViews() {
        try {
            recyclerView = findViewById(R.id.recyclerView);
            tvSongTitle = findViewById(R.id.tvSongTitle);
            tvArtistAlbum = findViewById(R.id.tvArtistAlbum);
            horizontalLyricsView = findViewById(R.id.horizontalLyricsView);
            seekBar = findViewById(R.id.seekBar);
            ivBackground = findViewById(R.id.ivBackground);
            ivAlbumCover = findViewById(R.id.ivAlbumCover);
            tvCurrentTime = findViewById(R.id.tvCurrentTime);
            tvTotalTime = findViewById(R.id.tvTotalTime);
            
            btnPrev = findViewById(R.id.btnPrev);
            btnPlayPause = findViewById(R.id.btnPlayPause);
            btnNext = findViewById(R.id.btnNext);
            btnMode = findViewById(R.id.btnMode);
            btnScan = findViewById(R.id.btnScan);
            btnRefresh = findViewById(R.id.btnRefresh);
            btnExit = findViewById(R.id.btnExit);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "findViewById error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            throw e;
        }
        
        // Exit button listener
        try {
            btnExit.setOnClickListener(v -> {
                // Stop playback
                if (musicService != null && musicBound) {
                    musicService.pausePlayer();
                    musicService.stopSelf(); // Stop the service
                }
                
                // Remove callbacks
                handler.removeCallbacks(updateTask);
                
                // Unbind service
                if (musicBound) {
                    try {
                        unbindService(musicConnection);
                        musicBound = false;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                
                // Stop the service intent
                if (playIntent != null) {
                    stopService(playIntent);
                }
                
                // Exit to desktop
                finish();
                System.exit(0);
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            btnPrev.setOnClickListener(v -> {
                if (musicService != null) musicService.playPrev();
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            btnNext.setOnClickListener(v -> {
                if (musicService != null) musicService.playNext();
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            btnPlayPause.setOnClickListener(v -> {
                if (musicService != null) {
                    if (musicService.isPng()) {
                        musicService.pausePlayer();
                        btnPlayPause.setImageResource(R.drawable.play);
                    } else {
                        musicService.resumePlayer();
                        btnPlayPause.setImageResource(R.drawable.pause);
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        try {
            btnMode.setOnClickListener(v -> {
                if (musicService != null) {
                    int mode = musicService.getPlayMode();
                    mode = (mode + 1) % 3;
                    musicService.setPlayMode(mode);
                    updateModeButton(mode);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            btnScan.setOnClickListener(v -> {
                new FilePickerDialog(this, file -> {
                    loadMusic(file);
                }).show();
            });
            
            // 长按显示挂载点诊断信息
            btnScan.setOnLongClickListener(v -> {
                showMountPointsInfo();
                return true;
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            btnRefresh.setOnClickListener(v -> {
                Toast.makeText(this, "Refreshing song list...", Toast.LENGTH_SHORT).show();
                String lastPath = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                        .getString(KEY_LAST_SCAN_PATH, null);
                if (lastPath != null) {
                    loadMusic(new File(lastPath));
                } else {
                    loadMusic(null);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                    handler.removeCallbacks(updateTask);
                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                    if (musicService != null && musicBound) {
                        int duration = musicService.getDur();
                        int newPosition = (duration * seekBar.getProgress()) / 100;
                        musicService.seek(newPosition);
                    }
                    handler.post(updateTask);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void updateModeButton(int mode) {
        if (btnMode != null) {
            switch (mode) {
                case MusicService.MODE_SEQUENCE: 
                    btnMode.setImageResource(R.drawable.seq); 
                    break;
                case MusicService.MODE_SINGLE: 
                    btnMode.setImageResource(R.drawable.sing); 
                    break;
                case MusicService.MODE_RANDOM: 
                    btnMode.setImageResource(R.drawable.rand); 
                    break;
            }
        }
        // Also update text mode
        updateModeText(mode);
    }
    
    /**
     * Update play mode text
     */
    private void updateModeText(int mode) {
        if (tvPlayMode == null) return;
        
        switch (mode) {
            case MusicService.MODE_SEQUENCE:
                tvPlayMode.setText("顺序播放");
                break;
            case MusicService.MODE_SINGLE:
                tvPlayMode.setText("单曲循环");
                break;
            case MusicService.MODE_RANDOM:
                tvPlayMode.setText("随机播放");
                break;
        }
    }
    
    /**
     * Update next song info
     */
    private void updateNextSongInfo() {
        if (tvNextSong == null || musicService == null) return;
        
        int currentPos = musicService.getCurrentPosition();
        int nextPos = -1;
        
        // Calculate next position based on play mode
        int mode = musicService.getPlayMode();
        if (mode == MusicService.MODE_SEQUENCE) {
            // Sequential: next song
            if (currentPos < songList.size() - 1) {
                nextPos = currentPos + 1;
            } else {
                nextPos = 0; // Loop to first
            }
        } else if (mode == MusicService.MODE_RANDOM) {
            // Random: can't predict, show hint
            tvNextSong.setText("下一首: 随机");
            return;
        } else {
            // Single repeat: same song
            nextPos = currentPos;
        }
        
        if (nextPos >= 0 && nextPos < songList.size()) {
            MusicBean nextSong = songList.get(nextPos);
            tvNextSong.setText("下一首: " + nextSong.title);
        }
    }


    private void loadCachedSongList() {
        try {
            String json = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                    .getString(KEY_SONG_LIST_CACHE, null);
            if (json != null) {
                Gson gson = new Gson();
                Type type = new TypeToken<List<MusicBean>>(){}.getType();
                List<MusicBean> cachedList = gson.fromJson(json, type);
                if (cachedList != null && !cachedList.isEmpty()) {
                    songList = cachedList;
                    adapter = new MusicAdapter(MainActivity.this, songList);
                    recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                    recyclerView.setAdapter(adapter);
                    
                    if (musicService != null) {
                        musicService.setPlaylist(songList);
                    }
                    
                    Toast.makeText(this, "Loaded " + songList.size() + " songs from cache", Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void saveSongListCache(List<MusicBean> list) {
        try {
            Gson gson = new Gson();
            String json = gson.toJson(list);
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                    .edit()
                    .putString(KEY_SONG_LIST_CACHE, json)
                    .apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void saveLastScanPath(File root) {
        if (root != null) {
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                    .edit()
                    .putString(KEY_LAST_SCAN_PATH, root.getAbsolutePath())
                    .apply();
        }
    }

    private void loadMusic(File specificRoot) {
        new Thread(() -> {
            List<MusicBean> tempSongList = new ArrayList<>();
            List<File> roots = new ArrayList<>();
            
            if (specificRoot != null) {
                // android.util.Log.d("MainActivity", "扫描指定目录: " + specificRoot.getAbsolutePath());
                roots.add(specificRoot);
            } else {
                // Auto-scan default roots
                // android.util.Log.d("MainActivity", "自动扫描默认目录...");
                
                // 内部存储
                File internalStorage = android.os.Environment.getExternalStorageDirectory();
                roots.add(internalStorage);
                // android.util.Log.d("MainActivity", "添加内部存储: " + internalStorage.getAbsolutePath());
                
                // 常见的 U 盘挂载点
                String[] usbPaths = {
                    "/mnt/usb_storage",
                    "/mnt/usbhost",
                    "/mnt/usbhost1",
                    "/mnt/udisk",
                    "/storage/usb0",
                    "/storage/usb1",
                    "/storage/udisk",
                    "/storage/usbdisk",
                    "/mnt/media_rw/udisk",
                    "/mnt/media_rw/usb_storage"
                };
                
                for (String path : usbPaths) {
                    File usbDir = new File(path);
                    if (usbDir.exists() && usbDir.canRead()) {
                        roots.add(usbDir);
                        // android.util.Log.d("MainActivity", "找到可用 U 盘路径: " + path);
                    }
                }
            }

            // android.util.Log.d("MainActivity", "总共扫描 " + roots.size() + " 个根目录");
            
            for (File root : roots) {
                if (root.exists() && root.isDirectory()) {
                    // android.util.Log.d("MainActivity", "开始扫描: " + root.getAbsolutePath());
                    int beforeCount = tempSongList.size();
                    scanDirectory(root, tempSongList);
                    int afterCount = tempSongList.size();
                    // android.util.Log.d("MainActivity", "扫描完成: " + root.getAbsolutePath() + ", 找到 " + (afterCount - beforeCount) + " 首歌曲");
                } else {
                    // android.util.Log.w("MainActivity", "跳过不存在或不可读的目录: " + root.getAbsolutePath());
                }
            }
            
            // 如果没有找到任何歌曲，尝试使用 MediaStore
            if (tempSongList.isEmpty()) {
                // android.util.Log.d("MainActivity", "文件扫描未找到歌曲，尝试使用 MediaStore...");
                scanFromMediaStore(tempSongList);
            }
            
            // ... (rest of sorting and UI update)

            Collections.sort(tempSongList, new Comparator<MusicBean>() {
                public int compare(MusicBean a, MusicBean b) {
                    return a.title.compareTo(b.title);
                }
            });

            runOnUiThread(() -> {
                songList = tempSongList; // Update member variable
                
                // Update old adapter (for compatibility, if still used)
                if (recyclerView != null) {
                    adapter = new MusicAdapter(MainActivity.this, songList);
                    recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                    recyclerView.setAdapter(adapter);
                }
                
                // Update song list tab
                filteredSongList.clear();
                filteredSongList.addAll(songList);
                Collections.sort(filteredSongList, (a, b) -> a.title.compareToIgnoreCase(b.title));
                if (songListAdapter != null) {
                    songListAdapter.notifyDataSetChanged();
                }
                
                if (musicService != null) {
                    musicService.setPlaylist(songList);
                }
                saveSongListCache(songList);
                
                // Save last scan path
                if (specificRoot != null) {
                    saveLastScanPath(specificRoot);
                } else if (!roots.isEmpty()) {
                    saveLastScanPath(roots.get(0));
                }
                
                android.util.Log.d("MainActivity", "扫描完成，总共找到 " + songList.size() + " 首歌曲");
                Toast.makeText(MainActivity.this, "Found " + songList.size() + " songs", Toast.LENGTH_SHORT).show();
            });
        }).start();
    }

    private void scanDirectory(File dir, List<MusicBean> list) {
        File[] files = dir.listFiles();
        if (files == null) return;

        for (File file : files) {
            if (file.isDirectory()) {
                // Skip hidden folders
                if (!file.getName().startsWith(".")) {
                    scanDirectory(file, list);
                }
            } else {
                String name = file.getName().toLowerCase();
                if (name.endsWith(".mp3") || name.endsWith(".flac") || name.endsWith(".wav") || name.endsWith(".ogg")) {
                    // Simple metadata extraction (can be improved with jaudiotagger if needed, but slow for list)
                    // For speed, we use filename as title initially
                    String title = file.getName();
                    int dot = title.lastIndexOf(".");
                    if (dot > 0) title = title.substring(0, dot);
                    
                    list.add(new MusicBean(System.currentTimeMillis(), file.getAbsolutePath(), title, "Unknown", "Unknown", 0));
                }
            }
        }
    }
    
    /**
     * 使用 MediaStore 扫描音乐文件（绕过文件权限限制）
     */
    private void scanFromMediaStore(List<MusicBean> list) {
        // android.util.Log.d("MainActivity", "开始 MediaStore 扫描...");
        
        String[] projection = {
            android.provider.MediaStore.Audio.Media._ID,
            android.provider.MediaStore.Audio.Media.DATA,
            android.provider.MediaStore.Audio.Media.TITLE,
            android.provider.MediaStore.Audio.Media.ARTIST,
            android.provider.MediaStore.Audio.Media.ALBUM,
            android.provider.MediaStore.Audio.Media.DURATION
        };
        
        String selection = android.provider.MediaStore.Audio.Media.IS_MUSIC + " != 0";
        
        android.database.Cursor cursor = null;
        try {
            cursor = getContentResolver().query(
                android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                null,
                android.provider.MediaStore.Audio.Media.TITLE + " ASC"
            );
            
            if (cursor != null && cursor.moveToFirst()) {
                int dataColumn = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.DATA);
                int titleColumn = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.TITLE);
                int artistColumn = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.ARTIST);
                int albumColumn = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.ALBUM);
                int durationColumn = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.DURATION);
                
                do {
                    String path = cursor.getString(dataColumn);
                    String title = cursor.getString(titleColumn);
                    String artist = cursor.getString(artistColumn);
                    String album = cursor.getString(albumColumn);
                    long duration = cursor.getLong(durationColumn);
                    
                    // 只添加支持的格式
                    if (path != null) {
                        String lowerPath = path.toLowerCase();
                        if (lowerPath.endsWith(".mp3") || lowerPath.endsWith(".flac") || 
                            lowerPath.endsWith(".wav") || lowerPath.endsWith(".ogg")) {
                            
                            if (title == null || title.isEmpty()) {
                                title = new File(path).getName();
                                int dot = title.lastIndexOf(".");
                                if (dot > 0) title = title.substring(0, dot);
                            }
                            
                            list.add(new MusicBean(
                                System.currentTimeMillis(),
                                path,
                                title,
                                artist != null ? artist : "Unknown",
                                album != null ? album : "Unknown",
                                duration
                            ));
                            
                            // android.util.Log.d("MainActivity", "MediaStore 找到: " + path);
                        }
                    }
                } while (cursor.moveToNext());
                
                // android.util.Log.d("MainActivity", "MediaStore 扫描完成，找到 " + list.size() + " 首歌曲");
            } else {
                // android.util.Log.w("MainActivity", "MediaStore 查询返回空结果");
            }
        } catch (Exception e) {
            // android.util.Log.e("MainActivity", "MediaStore 扫描失败: " + e.getMessage(), e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }
    
    /**
     * 显示所有挂载点信息，用于诊断 U 盘问题
     */
    private void showMountPointsInfo() {
        new Thread(() -> {
            StringBuilder info = new StringBuilder();
            info.append("=== 挂载点诊断 ===\n\n");
            
            String[] testPaths = {
                "/storage/udisk",
                "/storage/usb0",
                "/storage/usb1",
                "/mnt/usb_storage",
                "/mnt/usbhost",
                "/mnt/udisk",
                "/mnt/media_rw/udisk",
                "/mnt/media_rw/usb_storage"
            };
            
            for (String path : testPaths) {
                File dir = new File(path);
                info.append(path).append(":\n");
                info.append("  存在: ").append(dir.exists()).append("\n");
                info.append("  可读: ").append(dir.canRead()).append("\n");
                info.append("  可写: ").append(dir.canWrite()).append("\n");
                
                if (dir.exists() && dir.canRead()) {
                    File[] files = dir.listFiles();
                    info.append("  文件数: ").append(files != null ? files.length : "null").append("\n");
                }
                info.append("\n");
            }
            
            // 尝试读取 /proc/mounts
            try {
                info.append("=== /proc/mounts ===\n");
                Process process = Runtime.getRuntime().exec("cat /proc/mounts");
                java.io.BufferedReader reader = new java.io.BufferedReader(
                    new java.io.InputStreamReader(process.getInputStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.contains("usb") || line.contains("udisk") || line.contains("storage")) {
                        info.append(line).append("\n");
                    }
                }
                reader.close();
            } catch (Exception e) {
                info.append("读取 /proc/mounts 失败: ").append(e.getMessage()).append("\n");
            }
            
            final String message = info.toString();
            android.util.Log.d("MainActivity", message);
            
            runOnUiThread(() -> {
                new android.app.AlertDialog.Builder(this)
                    .setTitle("挂载点诊断")
                    .setMessage(message)
                    .setPositiveButton("确定", null)
                    .show();
            });
        }).start();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadMusic(null);
            } else {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        registerReceiver(updateUIReceiver, new IntentFilter(MusicService.ACTION_UPDATE_UI));
        handler.post(updateTask);
    }
    
    @Override
    protected void onStop() {
        super.onStop();
        try {
            unregisterReceiver(updateUIReceiver);
        } catch (Exception e) {
            // Receiver not registered
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (musicBound) {
            unbindService(musicConnection);
            musicBound = false;
        }
        handler.removeCallbacks(updateTask);
    }

    private int lastPlayingPosition = -1; // Track last playing position
    
    private void updateUI() {
        if (musicService != null && musicBound) {
            MusicBean currentSong = musicService.getCurrentSong();
            if (currentSong != null) {
                // Load real metadata from ID3 tags in background
                loadAndDisplayMetadata(currentSong);
                
                btnPlayPause.setImageResource(musicService.isPng() ? R.drawable.pause : R.drawable.play);
                
                // Load album cover
                loadAlbumCover(currentSong.path);
                
                // Load lyrics (only vertical lyrics now)
                if (lyricsView != null) {
                    final String path = currentSong.path;
                    
                    // 1. Check cache
                    List<HorizontalLyricsView.LyricLine> cachedLyrics = null;
                    if (mLyricsCache != null) {
                        cachedLyrics = mLyricsCache.get(path);
                    }
                    
                    if (cachedLyrics != null) {
                        // Cache hit - update vertical lyrics view
                        lyricsView.setLyricsFromMedia(new File(path));
                    } else {
                        // 2. Load in background
                        // Clear current lyrics first to avoid mismatch
                        lyricsView.setLyricsFromMedia(null);
                        
                        final java.lang.ref.WeakReference<MainActivity> weakActivity = new java.lang.ref.WeakReference<>(this);
                        final java.lang.ref.WeakReference<LyricsView> weakVerticalLyricsView = new java.lang.ref.WeakReference<>(lyricsView);
                        
                        new Thread(() -> {
                            try {
                                // Load lyrics using LyricsView's method
                                File audioFile = new File(path);
                                
                                // We still cache using HorizontalLyricsView format for compatibility
                                // but we don't need to actually use HorizontalLyricsView
                                List<HorizontalLyricsView.LyricLine> loadedLyrics = null;
                                
                                // Try to load lyrics
                                try {
                                    // Use a temporary HorizontalLyricsView instance just for loading
                                    if (weakActivity.get() != null) {
                                        HorizontalLyricsView tempView = new HorizontalLyricsView(weakActivity.get(), null);
                                        loadedLyrics = tempView.loadLyrics(audioFile);
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                
                                // Cache it
                                if (mLyricsCache != null && loadedLyrics != null) {
                                    mLyricsCache.put(path, loadedLyrics);
                                }
                                
                                // Update UI
                                MainActivity activity = weakActivity.get();
                                if (activity == null) return; // Activity已被回收
                                
                                activity.runOnUiThread(() -> {
                                    // Verify we are still playing the same song
                                    if (activity.musicService != null) {
                                        MusicBean nowPlaying = activity.musicService.getCurrentSong();
                                        LyricsView vView = weakVerticalLyricsView.get();
                                        if (nowPlaying != null && nowPlaying.path.equals(path) && vView != null) {
                                            vView.setLyricsFromMedia(new File(path));
                                        }
                                    }
                                });
                            } catch (Throwable e) {
                                e.printStackTrace();
                            }
                        }).start();
                    }
                }
                
                // Check if song position changed (next/prev/auto-play)
                int currentPos = musicService.getCurrentPosition();
                if (adapter != null) {
                    // 只处理高亮，暂不强制重排序，以免打断用户浏览
                    adapter.setCurrentPlayingPosition(currentPos);
                }
                lastPlayingPosition = currentPos;
                
                // Update next song info
                updateNextSongInfo();
            }
            updateModeButton(musicService.getPlayMode());
        }
    }
    
    /**
     * Reorder the playlist and play from the selected position
     * Example: [歌1, 歌2, 歌3, 歌4, 歌5] -> click 歌3 -> [歌3, 歌4, 歌5, 歌1, 歌2]
     */
    private void reorderAndPlayFrom(int clickedPosition) {
        if (songList == null || songList.isEmpty() || clickedPosition < 0 || clickedPosition >= songList.size()) {
            return;
        }
        
        // Create new reordered list
        List<MusicBean> reorderedList = new ArrayList<>();
        
        // Add from clicked position to end
        for (int i = clickedPosition; i < songList.size(); i++) {
            reorderedList.add(songList.get(i));
        }
        
        // Add from start to clicked position (exclusive)
        for (int i = 0; i < clickedPosition; i++) {
            reorderedList.add(songList.get(i));
        }
        
        // Update the song list
        songList.clear();
        songList.addAll(reorderedList);
        
        // Update service playlist
        if (musicService != null) {
            musicService.setPlaylist(songList);
            // Play from position 0 (which is now the clicked song)
            musicService.playSong(0);
        }
        
        // Update adapter
        if (adapter != null) {
            adapter.notifyDataSetChanged();
            adapter.setCurrentPlayingPosition(0);
        }
        
        // Scroll to top to show the playing song
        if (recyclerView != null) {
            recyclerView.scrollToPosition(0);
        }
        
        // Reset tracking
        lastPlayingPosition = 0;
    }
    
    /**
     * Reorder playlist to move current playing song to position 0
     * Used when song changes via next/prev/auto-play
     */
    private void reorderToPosition(int currentPosition) {
        if (songList == null || songList.isEmpty() || currentPosition <= 0 || currentPosition >= songList.size()) {
            return;
        }
        
        // Create new reordered list
        List<MusicBean> reorderedList = new ArrayList<>();
        
        // Add from current position to end
        for (int i = currentPosition; i < songList.size(); i++) {
            reorderedList.add(songList.get(i));
        }
        
        // Add from start to current position (exclusive)
        for (int i = 0; i < currentPosition; i++) {
            reorderedList.add(songList.get(i));
        }
        
        // Update the song list
        songList.clear();
        songList.addAll(reorderedList);
        
        // Update service playlist (without restarting playback)
        if (musicService != null) {
            musicService.setPlaylist(songList);
            // Don't call playSong() - let current playback continue
        }
        
        // Update adapter
        if (adapter != null) {
            adapter.notifyDataSetChanged();
            adapter.setCurrentPlayingPosition(0);
        }
        
        // Scroll to top to show the playing song
        if (recyclerView != null) {
            recyclerView.scrollToPosition(0);
        }
        
        // Update tracking to position 0
        lastPlayingPosition = 0;
    }

    private void loadAndDisplayMetadata(MusicBean song) {
        // 1. Check cache first
        if (mMetadataCache != null) {
            MetadataInfo cached = mMetadataCache.get(song.path);
            if (cached != null) {
                updateMetadataUI(cached.title, cached.artist, cached.album);
                return;
            }
        }
        
        // 2. Load in background
        final java.lang.ref.WeakReference<MainActivity> weakActivity = new java.lang.ref.WeakReference<>(this);
        
        new Thread(() -> {
            String title = song.title;  // Default to filename
            String artist = "Unknown Artist";
            String album = "Unknown Album";
            
            android.media.MediaMetadataRetriever retriever = null;
            try {
                // Check file existence
                File audioFileObj = new File(song.path);
                if (!audioFileObj.exists() || !audioFileObj.canRead()) {
                    MainActivity activity = weakActivity.get();
                    if (activity != null) {
                        activity.updateMetadataUI(title, artist, album);
                    }
                    return;
                }
                
                retriever = new android.media.MediaMetadataRetriever();
                retriever.setDataSource(song.path);
                
                // Extract title
                String metaTitle = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_TITLE);
                if (metaTitle != null && !metaTitle.trim().isEmpty()) {
                    title = metaTitle;
                }
                
                // Extract artist
                String metaArtist = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ARTIST);
                if (metaArtist != null && !metaArtist.trim().isEmpty()) {
                    artist = metaArtist;
                }
                
                // Extract album
                String metaAlbum = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ALBUM);
                if (metaAlbum != null && !metaAlbum.trim().isEmpty()) {
                    album = metaAlbum;
                }
                
                // Cache the metadata
                if (mMetadataCache != null) {
                    mMetadataCache.put(song.path, new MetadataInfo(title, artist, album));
                }
                
            } catch (Throwable e) {
                // Silent fail, use defaults
            } finally {
                if (retriever != null) {
                    try {
                        retriever.release();
                    } catch (Exception e) {
                        // Ignore
                    }
                }
            }
            
            final String finalTitle = title;
            final String finalArtist = artist;
            final String finalAlbum = album;
            
            MainActivity activity = weakActivity.get();
            if (activity != null) {
                activity.updateMetadataUI(finalTitle, finalArtist, finalAlbum);
            }
        }).start();
    }
    
    private void updateMetadataUI(String title, String artist, String album) {
        runOnUiThread(() -> {
            try {
                if (tvSongTitle != null) {
                    tvSongTitle.setText(title);
                }
                if (tvArtistAlbum != null) {
                    tvArtistAlbum.setText(album);
                }
            } catch (Exception e) {
                android.util.Log.e("MainActivity", "Error updating UI: " + e.getMessage(), e);
            }
        });
    }
    
    /**
     * Load and display album cover in ivAlbumCover
     */
    private void loadAlbumCover(String audioFilePath) {
        if (audioFilePath == null || ivAlbumCover == null) {
            return;
        }
        
        // 1. Check cache first
        if (mCoverCache != null) {
            Bitmap cachedBitmap = mCoverCache.get(audioFilePath);
            if (cachedBitmap != null) {
                ivAlbumCover.setImageBitmap(cachedBitmap);
                return;
            }
        }
        
        // 2. Load in background
        final java.lang.ref.WeakReference<MainActivity> weakActivity = new java.lang.ref.WeakReference<>(this);
        final java.lang.ref.WeakReference<ImageView> weakImageView = new java.lang.ref.WeakReference<>(ivAlbumCover);
        
        new Thread(() -> {
            android.media.MediaMetadataRetriever retriever = null;
            try {
                // Check file existence
                File audioFileObj = new File(audioFilePath);
                if (!audioFileObj.exists() || !audioFileObj.canRead()) {
                    showDefaultAlbumCover(weakActivity, weakImageView);
                    return;
                }

                retriever = new android.media.MediaMetadataRetriever();
                retriever.setDataSource(audioFilePath);
                
                // Get embedded picture
                byte[] imageData = retriever.getEmbeddedPicture();
                
                if (imageData != null && imageData.length > 0) {
                    // Optimize bitmap decoding (优化 5)
                    BitmapFactory.Options options = new BitmapFactory.Options();
                    options.inSampleSize = 2; // 缩小到 1/2，减少内存占用
                    options.inPreferredConfig = Bitmap.Config.RGB_565; // 使用 RGB_565 格式，节省 50% 内存
                    
                    final Bitmap bitmap = BitmapFactory.decodeByteArray(imageData, 0, imageData.length, options);
                    
                    if (bitmap != null) {
                        // Cache the bitmap
                        if (mCoverCache != null) {
                            mCoverCache.put(audioFilePath, bitmap);
                        }
                        
                        MainActivity activity = weakActivity.get();
                        ImageView imageView = weakImageView.get();
                        if (activity != null && imageView != null) {
                            activity.runOnUiThread(() -> {
                                imageView.setImageBitmap(bitmap);
                            });
                        }
                        return;
                    }
                }
            } catch (Throwable e) {
                // Silent fail, use defaults
            } finally {
                if (retriever != null) {
                    try {
                        retriever.release();
                    } catch (Exception e) {
                    }
                }
            }
            
            // If no album art or error, show default logo
            showDefaultAlbumCover(weakActivity, weakImageView);
        }).start();
    }
    
    private void showDefaultAlbumCover(java.lang.ref.WeakReference<MainActivity> weakActivity, 
                                       java.lang.ref.WeakReference<ImageView> weakImageView) {
        MainActivity activity = weakActivity.get();
        ImageView imageView = weakImageView.get();
        if (activity != null && imageView != null) {
            activity.runOnUiThread(() -> {
                try {
                    // 使用 drawable 目录下的 noimg.jpeg 作为默认封面
                    imageView.setImageResource(R.drawable.noimg);
                } catch (Exception e) {
                    // 如果 noimg 不存在，使用纯色背景
                    imageView.setImageResource(android.R.color.darker_gray);
                }
            });
        }
    }
    

    private void loadAlbumArtBackground(String audioFilePath) {
        if (audioFilePath == null || ivBackground == null) {
            return;
        }
        
        new Thread(() -> {
            try {
                Bitmap albumArt = extractAlbumArt(audioFilePath);
                if (albumArt != null) {
                    Bitmap blurred = blurBitmap(albumArt, 25f);
                    if (blurred != null) {
                        runOnUiThread(() -> {
                            if (ivBackground != null) {
                                ivBackground.setImageBitmap(blurred);
                            }
                        });
                    }
                } else {
                    runOnUiThread(() -> {
                        if (ivBackground != null) {
                            ivBackground.setImageResource(R.drawable.bg);
                        }
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> {
                    if (ivBackground != null) {
                        try {
                            ivBackground.setImageResource(R.drawable.bg);
                        } catch (Exception ex) {
                            // Ignore
                        }
                    }
                });
            }
        }).start();
    }

    private Bitmap extractAlbumArt(String audioFilePath) {
        try {
            org.jaudiotagger.audio.AudioFile audioFile = org.jaudiotagger.audio.AudioFileIO.read(new File(audioFilePath));
            org.jaudiotagger.tag.Tag tag = audioFile.getTag();
            
            if (tag != null) {
                org.jaudiotagger.tag.images.Artwork artwork = tag.getFirstArtwork();
                if (artwork != null) {
                    byte[] imageData = artwork.getBinaryData();
                    if (imageData != null && imageData.length > 0) {
                        Bitmap bitmap = BitmapFactory.decodeByteArray(imageData, 0, imageData.length);
                        if (bitmap != null) {
                            return bitmap;
                        }
                    }
                }
            }
        } catch (Exception e) {
            // Silently fail
        }
        
        return null;
    }

    private Bitmap blurBitmap(Bitmap bitmap, float radius) {
        try {
            // Scale down for better performance
            int width = bitmap.getWidth() / 4;
            int height = bitmap.getHeight() / 4;
            Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, width, height, false);

            Bitmap outputBitmap = Bitmap.createBitmap(scaledBitmap);

            RenderScript rs = null;
            try {
                rs = RenderScript.create(this);
                ScriptIntrinsicBlur blurScript = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
                Allocation tmpIn = Allocation.createFromBitmap(rs, scaledBitmap);
                Allocation tmpOut = Allocation.createFromBitmap(rs, outputBitmap);

                blurScript.setRadius(radius);
                blurScript.setInput(tmpIn);
                blurScript.forEach(tmpOut);
                tmpOut.copyTo(outputBitmap);

                return outputBitmap;
            } finally {
                if (rs != null) {
                    rs.destroy();
                }
            }
        } catch (Exception e) {
            // RenderScript failed, use simple scaled bitmap as fallback
            e.printStackTrace();
            try {
                int width = bitmap.getWidth() / 4;
                int height = bitmap.getHeight() / 4;
                return Bitmap.createScaledBitmap(bitmap, width, height, true);
            } catch (Exception ex) {
                return bitmap;
            }
        }
    }

    // Inner Adapter Class
    
    /**
     * Adapter for song list tab (simple, performance-optimized)
     */
    class SongListAdapter extends RecyclerView.Adapter<SongListAdapter.ViewHolder> {
        private Context context;
        private List<MusicBean> list;
        
        public SongListAdapter(Context context, List<MusicBean> list) {
            this.context = context;
            this.list = list;
        }
        
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_song_simple, parent, false);
            return new ViewHolder(view);
        }
        
        @Override
        public void onBindViewHolder(ViewHolder holder, final int position) {
            MusicBean song = list.get(position);
            holder.tvSongName.setText(song.title);
            
            // Show playing indicator if this is the current song
            if (musicService != null && musicService.getCurrentSong() != null) {
                if (musicService.getCurrentSong().path.equals(song.path)) {
                    holder.tvPlayingIndicator.setVisibility(View.VISIBLE);
                    holder.itemView.setBackgroundColor(0x22FF6B35); // Light orange tint
                } else {
                    holder.tvPlayingIndicator.setVisibility(View.GONE);
                    holder.itemView.setBackgroundColor(0x00000000); // Transparent
                }
            }
            
            // Click to play
            holder.itemView.setOnClickListener(v -> {
                if (musicService != null) {
                    // Find the position in the original songList
                    int originalPosition = songList.indexOf(song);
                    if (originalPosition >= 0) {
                        // Set playlist and play
                        musicService.setPlaylist(songList);
                        musicService.playSong(originalPosition);
                        
                        // Switch to player tab
                        switchToTab(1);
                    }
                }
            });
        }
        
        @Override
        public int getItemCount() {
            return list.size();
        }
        
        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvSongName;
            TextView tvPlayingIndicator;
            
            public ViewHolder(View itemView) {
                super(itemView);
                tvSongName = itemView.findViewById(R.id.tvSongName);
                tvPlayingIndicator = itemView.findViewById(R.id.tvPlayingIndicator);
            }
        }
    }

    class MusicAdapter extends RecyclerView.Adapter<MusicAdapter.ViewHolder> {
        private Context context;
        private List<MusicBean> list;
        private int currentPlayingPosition = -1;

        public MusicAdapter(Context context, List<MusicBean> list) {
            this.context = context;
            this.list = list;
        }
        
        public void setCurrentPlayingPosition(int position) {
            int oldPosition = currentPlayingPosition;
            currentPlayingPosition = position;
            
            // Notify both old and new positions to update their appearance
            if (oldPosition != -1) {
                notifyItemChanged(oldPosition);
            }
            if (currentPlayingPosition != -1) {
                notifyItemChanged(currentPlayingPosition);
            }
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_music, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, final int position) {
            MusicBean song = list.get(position);
            holder.title.setText(song.title);
            
            // Highlight current playing song with light blue background
            if (position == currentPlayingPosition) {
                holder.itemView.setBackgroundColor(0xFF87CEEB); // Light blue (SkyBlue)
            } else {
                holder.itemView.setBackgroundColor(0x00000000); // Transparent
            }
            
            holder.itemView.setOnClickListener(v -> {
                if (musicService != null) {
                    // Reorder playlist and play from selected position
                    reorderAndPlayFrom(position);
                } else {
                    Toast.makeText(context, "Service not bound", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView title;
            public ViewHolder(View itemView) {
                super(itemView);
                title = itemView.findViewById(R.id.itemTitle);
            }
        }
    }
    
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (musicService != null) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_MEDIA_NEXT:
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                    musicService.playNext();
                    return true;
                    
                case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                case KeyEvent.KEYCODE_DPAD_LEFT:
                    musicService.playPrev();
                    return true;
                    
                case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER:
                    if (musicService.isPng()) {
                        musicService.pausePlayer();
                    } else {
                        musicService.resumePlayer();
                    }
                    return true;
                    
                case KeyEvent.KEYCODE_MEDIA_PLAY:
                    musicService.resumePlayer();
                    return true;
                    
                case KeyEvent.KEYCODE_MEDIA_PAUSE:
                    musicService.pausePlayer();
                    return true;
            }
        }
        
        return super.onKeyDown(keyCode, event);
    }

    private String formatTime(long ms) {
        long seconds = (ms / 1000) % 60;
        long minutes = (ms / 1000) / 60;
        return String.format("%d:%02d", minutes, seconds);
    }
}
