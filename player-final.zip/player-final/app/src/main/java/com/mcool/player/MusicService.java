package com.mcool.player;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.view.KeyEvent;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import androidx.core.app.NotificationCompat;
import androidx.media.session.MediaButtonReceiver;

import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MusicService extends Service implements MediaPlayer.OnPreparedListener, MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener {

    private MediaPlayer player;
    private List<MusicBean> playlist = new ArrayList<>();
    private int currentPosition = -1;
    private final IBinder musicBind = new MusicBinder();
    private MediaSessionCompat mediaSession;
    private PowerManager.WakeLock wakeLock;

    // Playback modes
    public static final int MODE_SEQUENCE = 0;
    public static final int MODE_SINGLE = 1;
    public static final int MODE_RANDOM = 2;
    private int playMode = MODE_SEQUENCE;

    public static final String ACTION_UPDATE_UI = "com.mcool.player.UPDATE_UI";

    @Override
    public void onCreate() {
        super.onCreate();
        player = new MediaPlayer();
        initPlayer(); // Renamed from initMusicPlayer()
        initMediaSession();
        
        // Register media button receiver as fallback
        registerMediaButtonReceiver();
        
        wakeLock = ((PowerManager) getSystemService(Context.POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, getClass().getName());
        wakeLock.setReferenceCounted(false);
    }
    
    private void registerMediaButtonReceiver() {
        try {
            IntentFilter filter = new IntentFilter();
            
            // Standard media button actions
            filter.addAction(Intent.ACTION_MEDIA_BUTTON);
            filter.addAction("android.intent.action.MEDIA_BUTTON");
            
            // Common car head unit actions
            filter.addAction("com.android.music.musicservicecommand");
            filter.addAction("android.media.AUDIO_BECOMING_NOISY");
            
            // Possible steering wheel control actions
            filter.addAction("com.haoke.media.MUSIC_CONTROL");
            filter.addAction("com.bdstar.media.MUSIC_CONTROL");
            filter.addAction("android.intent.action.MEDIA_PLAY");
            filter.addAction("android.intent.action.MEDIA_PAUSE");
            filter.addAction("android.intent.action.MEDIA_NEXT");
            filter.addAction("android.intent.action.MEDIA_PREVIOUS");
            
            filter.setPriority(IntentFilter.SYSTEM_HIGH_PRIORITY);
            registerReceiver(mediaButtonReceiver, filter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private final BroadcastReceiver mediaButtonReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            
            // Handle standard media button
            if (Intent.ACTION_MEDIA_BUTTON.equals(action)) {
                KeyEvent event = intent.getParcelableExtra(Intent.EXTRA_KEY_EVENT);
                if (event != null && event.getAction() == KeyEvent.ACTION_DOWN) {
                    handleKeyEvent(event.getKeyCode());
                    abortBroadcast();
                }
                return;
            }
            
            // Handle direct action intents
            if ("android.intent.action.MEDIA_NEXT".equals(action) || 
                "com.haoke.media.MUSIC_CONTROL".equals(action) && "next".equals(intent.getStringExtra("command"))) {
                playNext();
                abortBroadcast();
            } else if ("android.intent.action.MEDIA_PREVIOUS".equals(action) ||
                       "com.haoke.media.MUSIC_CONTROL".equals(action) && "previous".equals(intent.getStringExtra("command"))) {
                playPrev();
                abortBroadcast();
            } else if ("android.intent.action.MEDIA_PLAY".equals(action)) {
                resumePlayer();
                abortBroadcast();
            } else if ("android.intent.action.MEDIA_PAUSE".equals(action)) {
                pausePlayer();
                abortBroadcast();
            }
            
            // Handle musicservicecommand (used by some music apps)
            if ("com.android.music.musicservicecommand".equals(action)) {
                String cmd = intent.getStringExtra("command");
                if ("next".equals(cmd)) {
                    playNext();
                } else if ("previous".equals(cmd)) {
                    playPrev();
                } else if ("pause".equals(cmd)) {
                    pausePlayer();
                } else if ("play".equals(cmd)) {
                    resumePlayer();
                } else if ("togglepause".equals(cmd)) {
                    if (isPng()) {
                        pausePlayer();
                    } else {
                        resumePlayer();
                    }
                }
                abortBroadcast();
            }
        }
        
        private void handleKeyEvent(int keyCode) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_MEDIA_PLAY:
                    resumePlayer();
                    break;
                case KeyEvent.KEYCODE_MEDIA_PAUSE:
                    pausePlayer();
                    break;
                case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                    if (isPng()) {
                        pausePlayer();
                    } else {
                        resumePlayer();
                    }
                    break;
                case KeyEvent.KEYCODE_MEDIA_NEXT:
                    playNext();
                    break;
                case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                    playPrev();
                    break;
            }
        }
    };

    // Renamed from initMusicPlayer() to initPlayer()
    private void initPlayer() {
        player.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);
        player.setAudioStreamType(AudioManager.STREAM_MUSIC);
        player.setOnPreparedListener(this);
        player.setOnCompletionListener(this);
        player.setOnErrorListener(this);
    }

    private void initMediaSession() {
        try {
            // Use the constructor without MediaButtonReceiver for Android 4.4 compatibility
            ComponentName mediaButtonReceiver = null;  // Optional on Android 4.4
            mediaSession = new MediaSessionCompat(this, "MusicService", mediaButtonReceiver, null);
            mediaSession.setFlags(MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS | MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS);
            mediaSession.setCallback(new MediaSessionCompat.Callback() {
                @Override
                public void onPlay() {
                    super.onPlay();
                    resumePlayer();
                }

                @Override
                public void onPause() {
                    super.onPause();
                    pausePlayer();
                }

                @Override
                public void onSkipToNext() {
                    super.onSkipToNext();
                    playNext();
                }

                @Override
                public void onSkipToPrevious() {
                    super.onSkipToPrevious();
                    playPrev();
                }

                @Override
                public void onStop() {
                    super.onStop();
                    pausePlayer();
                }
            });
            mediaSession.setActive(true);
        } catch (Exception e) {
            e.printStackTrace();
            // If MediaSession fails, continue without it
            mediaSession = null;
        }
    }

    public void setPlaylist(List<MusicBean> songs) {
        playlist = songs;
    }

    public class MusicBinder extends Binder {
        MusicService getService() {
            return MusicService.this;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return musicBind;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        return false;
    }

    public void playSong(int songIndex) {
        try {
            if (playlist == null || playlist.isEmpty()) {
                Toast.makeText(getApplicationContext(), "Playlist is empty", Toast.LENGTH_SHORT).show();
                return;
            }
            
            if (songIndex < 0 || songIndex >= playlist.size()) {
                 Toast.makeText(getApplicationContext(), "Invalid song index", Toast.LENGTH_SHORT).show();
                 return;
            }
            
            player.reset();
            currentPosition = songIndex;
            MusicBean playSong = playlist.get(currentPosition);

            try {
                player.setDataSource(playSong.path);
                player.prepareAsync();
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(getApplicationContext(), "Error playing: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "Unexpected error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onPrepared(MediaPlayer mp) {
        try {
            mp.start();
            if (wakeLock != null && !wakeLock.isHeld()) {
                wakeLock.acquire();
            }
            
            updateNotification();
            updateMediaSessionState(PlaybackStateCompat.STATE_PLAYING);
            sendUpdateUIBroadcast();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "Error starting playback: " + e.getMessage(), Toast.LENGTH_LONG).show();
            updateMediaSessionState(PlaybackStateCompat.STATE_ERROR); // Indicate error in media session
        }
    }

    public void pausePlayer() {
        if (player.isPlaying()) {
            player.pause();
            if (wakeLock.isHeld()) wakeLock.release();
            updateMediaSessionState(PlaybackStateCompat.STATE_PAUSED);
            // Stop foreground but keep notification
            stopForeground(false);
        }
    }

    public void resumePlayer() {
        if (!player.isPlaying()) {
            player.start();
            if (!wakeLock.isHeld()) wakeLock.acquire();
            updateMediaSessionState(PlaybackStateCompat.STATE_PLAYING);
            updateNotification();
        }
    }

    public void playNext() {
        if (playlist.isEmpty()) return;
        
        if (playMode == MODE_RANDOM) {
            int newPos = currentPosition;
            while (newPos == currentPosition && playlist.size() > 1) {
                newPos = new Random().nextInt(playlist.size());
            }
            currentPosition = newPos;
        } else {
            currentPosition++;
            if (currentPosition >= playlist.size()) currentPosition = 0;
        }
        playSong(currentPosition);
    }

    public void playPrev() {
        if (playlist.isEmpty()) return;
        currentPosition--;
        if (currentPosition < 0) currentPosition = playlist.size() - 1;
        playSong(currentPosition);
    }
    
    public void setPlayMode(int mode) {
        this.playMode = mode;
    }
    
    public int getPlayMode() {
        return playMode;
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        if (playMode == MODE_SINGLE) {
            playSong(currentPosition);
        } else {
            playNext();
        }
    }

    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        mp.reset();
        return false;
    }
    
    public int getPosn() {
        return player.getCurrentPosition();
    }

    public int getDur() {
        return player.getDuration();
    }

    public boolean isPng() {
        return player.isPlaying();
    }
    
    public MusicBean getCurrentSong() {
        if (playlist != null && currentPosition >= 0 && currentPosition < playlist.size()) {
            return playlist.get(currentPosition);
        }
        return null;
    }
    
    public int getCurrentPosition() {
        return currentPosition;
    }

    public void seek(int position) {
        try {
            if (player != null) {
                player.seekTo(position);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateMediaSessionState(int state) {
        if (mediaSession == null) {
            return; // MediaSession not available, skip update
        }
        
        PlaybackStateCompat.Builder playbackStateBuilder = new PlaybackStateCompat.Builder();
        if (state == PlaybackStateCompat.STATE_PLAYING) {
            playbackStateBuilder.setActions(PlaybackStateCompat.ACTION_PLAY_PAUSE | PlaybackStateCompat.ACTION_PAUSE | PlaybackStateCompat.ACTION_SKIP_TO_NEXT | PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS);
        } else {
            playbackStateBuilder.setActions(PlaybackStateCompat.ACTION_PLAY_PAUSE | PlaybackStateCompat.ACTION_PLAY | PlaybackStateCompat.ACTION_SKIP_TO_NEXT | PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS);
        }
        playbackStateBuilder.setState(state, PlaybackStateCompat.PLAYBACK_POSITION_UNKNOWN, 1);
        mediaSession.setPlaybackState(playbackStateBuilder.build());
    }

    private void updateNotification() {
        try {
            String channelId = "mcool_channel";
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationHelper.createChannel(this, channelId);
            }

            Intent notIntent = new Intent(this, MainActivity.class);
            notIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                flags |= PendingIntent.FLAG_IMMUTABLE;
            }
            PendingIntent pendInt = PendingIntent.getActivity(this, 0, notIntent, flags);

            MusicBean song = getCurrentSong();
            String title = (song != null) ? song.title : "播放器";
            String artist = (song != null) ? song.artist : "";

            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, channelId);
            builder.setContentIntent(pendInt)
                    .setSmallIcon(R.drawable.logo)
                    .setTicker(title)
                    .setOngoing(true)
                    .setContentTitle(title)
                    .setContentText(artist);
                    
            startForeground(1, builder.build());
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }
    
    // Separate class to avoid verification errors on older Android versions
    private static class NotificationHelper {
        static void createChannel(Context context, String channelId) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel chan = new NotificationChannel(channelId, "Music Playback", NotificationManager.IMPORTANCE_LOW);
                chan.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
                NotificationManager service = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                if (service != null) {
                    service.createNotificationChannel(chan);
                }
            }
        }
    }
    
    private void sendUpdateUIBroadcast() {
        Intent intent = new Intent(ACTION_UPDATE_UI);
        sendBroadcast(intent);
    }

    @Override
    public void onDestroy() {
        try {
            unregisterReceiver(mediaButtonReceiver);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
        
        if (mediaSession != null) {
            mediaSession.release();
        }
        
        if (player != null) {
            player.stop();
            player.release();
        }
        
        super.onDestroy();
    }
}
