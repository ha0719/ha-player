package com.mcool.player;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

import org.jaudiotagger.audio.AudioFile;
import org.jaudiotagger.audio.AudioFileIO;
import org.jaudiotagger.tag.FieldKey;
import org.jaudiotagger.tag.Tag;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LyricsView extends View {

    private List<LyricLine> lyrics = new ArrayList<>();
    private Paint paintHL, paintNormal;
    private int width, height;
    private int currentLine = 0;
    private float lineHeight = 80; // Pixel height per line
    private float scrollY = 0;

    public LyricsView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        paintHL = new Paint();
        paintHL.setColor(Color.WHITE);  // Changed from YELLOW to WHITE
        paintHL.setTextSize(30);  // Normal + 2 (28 + 2)
        paintHL.setAntiAlias(true);
        paintHL.setTextAlign(Paint.Align.CENTER);
        paintHL.setTypeface(Typeface.DEFAULT_BOLD);

        paintNormal = new Paint();
        paintNormal.setColor(Color.WHITE);
        paintNormal.setTextSize(28);  // Normal size
        paintNormal.setAntiAlias(true);
        paintNormal.setTextAlign(Paint.Align.CENTER);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (lyrics == null || lyrics.isEmpty()) {
            canvas.drawText("No Lyrics", width / 2, height / 2, paintNormal);
            return;
        }

        // Smooth scrolling calculation - optimized for low-end devices
        float targetY = currentLine * lineHeight;
        scrollY += (targetY - scrollY) * 0.4f; // Increased from 0.1 to 0.4 for smoother performance

        float centerY = height / 2;
        
        // Add padding for text wrapping
        int padding = 20;
        int maxWidth = width - (padding * 2);
        
        // Track cumulative Y position
        float cumulativeY = centerY - scrollY;
        
        for (int i = 0; i < lyrics.size(); i++) {
            String text = lyrics.get(i).text;
            Paint paint = (i == currentLine) ? paintHL : paintNormal;
            
            // Calculate if text needs wrapping
            float textWidth = paint.measureText(text);
            
            if (textWidth <= maxWidth) {
                // Single line - draw centered
                float y = cumulativeY;
                
                // Optimization: Don't draw if out of screen
                if (!(y < -lineHeight || y > height + lineHeight)) {
                    canvas.drawText(text, width / 2, y, paint);
                }
                
                // Move to next line position
                cumulativeY += lineHeight;
            } else {
                // Multi-line - wrap text
                List<String> lines = wrapText(text, maxWidth, paint);
                
                for (int j = 0; j < lines.size(); j++) {
                    float y = cumulativeY + (j * lineHeight * 0.8f);
                    
                    // Optimization: Don't draw if out of screen
                    if (!(y < -lineHeight || y > height + lineHeight)) {
                        canvas.drawText(lines.get(j), width / 2, y, paint);
                    }
                }
                
                // Move to next line position (account for all wrapped lines)
                cumulativeY += lines.size() * lineHeight * 0.8f;
            }
        }
        
        // Keep redrawing for animation if scrolling
        if (Math.abs(targetY - scrollY) > 1) {
            invalidate();
        }
    }
    
    /**
     * Wrap text to fit within maxWidth
     */
    private List<String> wrapText(String text, int maxWidth, Paint paint) {
        List<String> lines = new ArrayList<>();
        
        if (text == null || text.isEmpty()) {
            return lines;
        }
        
        String[] words = text.split(" ");
        StringBuilder currentLine = new StringBuilder();
        
        for (String word : words) {
            String testLine = currentLine.length() == 0 ? word : currentLine + " " + word;
            float testWidth = paint.measureText(testLine);
            
            if (testWidth <= maxWidth) {
                currentLine = new StringBuilder(testLine);
            } else {
                // Current line is full, start new line
                if (currentLine.length() > 0) {
                    lines.add(currentLine.toString());
                    currentLine = new StringBuilder(word);
                } else {
                    // Single word is too long, force break
                    lines.add(word);
                }
            }
        }
        
        // Add last line
        if (currentLine.length() > 0) {
            lines.add(currentLine.toString());
        }
        
        return lines;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        this.width = w;
        this.height = h;
    }

    public void updateTime(long time) {
        if (lyrics.isEmpty()) return;

        // Find current line based on time
        int newLine = 0;
        for (int i = 0; i < lyrics.size(); i++) {
            if (lyrics.get(i).time > time) {
                break;
            }
            newLine = i;
        }

        if (newLine != currentLine) {
            currentLine = newLine;
            invalidate();
        }
    }

    /**
     * Load lyrics: Priority 1: ID3 Tag, Priority 2: .lrc file
     */
    public void setLyricsFromMedia(File mediaFile) {
        lyrics.clear();
        currentLine = 0;
        scrollY = 0;
        
        if (mediaFile == null || !mediaFile.exists()) {
            invalidate();
            return;
        }

        new Thread(() -> {
            List<LyricLine> tempList = new ArrayList<>();
            
            // 1. Try reading from ID3 Tag
            try {
                AudioFile f = AudioFileIO.read(mediaFile);
                Tag tag = f.getTag();
                if (tag != null) {
                    String lyricsText = tag.getFirst(FieldKey.LYRICS);
                    if (lyricsText != null && !lyricsText.isEmpty()) {
                        tempList = parseLyricsString(lyricsText);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            // 2. If ID3 failed, try .lrc file
            if (tempList.isEmpty()) {
                String lrcPath = mediaFile.getAbsolutePath();
                int lastDot = lrcPath.lastIndexOf(".");
                if (lastDot > 0) {
                    lrcPath = lrcPath.substring(0, lastDot) + ".lrc";
                    File lrcFile = new File(lrcPath);
                    if (lrcFile.exists()) {
                        tempList = parseLrcFile(lrcFile);
                    }
                }
            }

            Collections.sort(tempList);
            
            final List<LyricLine> finalLyrics = tempList;
            post(() -> {
                lyrics.addAll(finalLyrics);
                invalidate();
            });
        }).start();
    }

    private List<LyricLine> parseLyricsString(String text) {
        List<LyricLine> list = new ArrayList<>();
        // Simple parser for [mm:ss.xx] format in string
        Pattern pattern = Pattern.compile("\\[(\\d{2}):(\\d{2})\\.(\\d{2,3})\\](.*)");
        String[] lines = text.split("\\n");
        for (String line : lines) {
            Matcher matcher = pattern.matcher(line);
            if (matcher.matches()) {
                long min = Long.parseLong(matcher.group(1));
                long sec = Long.parseLong(matcher.group(2));
                long mil = Long.parseLong(matcher.group(3));
                if (matcher.group(3).length() == 2) mil *= 10;
                long time = min * 60000 + sec * 1000 + mil;
                String content = matcher.group(4).trim();
                list.add(new LyricLine(time, content));
            }
        }
        return list;
    }

    private List<LyricLine> parseLrcFile(File file) {
        List<LyricLine> list = new ArrayList<>();
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "GBK"));
            String line;
            Pattern pattern = Pattern.compile("\\[(\\d{2}):(\\d{2})\\.(\\d{2,3})\\](.*)");
            while ((line = br.readLine()) != null) {
                Matcher matcher = pattern.matcher(line);
                if (matcher.matches()) {
                    long min = Long.parseLong(matcher.group(1));
                    long sec = Long.parseLong(matcher.group(2));
                    long mil = Long.parseLong(matcher.group(3));
                    if (matcher.group(3).length() == 2) mil *= 10;
                    long time = min * 60000 + sec * 1000 + mil;
                    String content = matcher.group(4).trim();
                    list.add(new LyricLine(time, content));
                }
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    private static class LyricLine implements Comparable<LyricLine> {
        long time;
        String text;

        public LyricLine(long time, String text) {
            this.time = time;
            this.text = text;
        }

        @Override
        public int compareTo(LyricLine o) {
            return Long.compare(this.time, o.time);
        }
    }
}
