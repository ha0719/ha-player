package com.mcool.player;

public class MusicBean {
    public String path;
    public String title;
    public String artist;
    public String album;
    public long duration;
    public long id;

    public MusicBean(long id, String path, String title, String artist, String album, long duration) {
        this.id = id;
        this.path = path;
        this.title = title;
        this.artist = artist;
        this.album = album;
        this.duration = duration;
    }
}
