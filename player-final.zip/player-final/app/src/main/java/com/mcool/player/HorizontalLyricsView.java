package com.mcool.player;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Horizontal scrolling lyrics view
 * Displays lyrics horizontally with time synchronization
 */
public class HorizontalLyricsView extends View {
    
    private List<LyricLine> lyrics = new ArrayList<>();
    private long currentTime = 0;
    private int currentLineIndex = -1;
    
    private Paint currentPaint;
    private Paint otherPaint;
    
    private static final float CURRENT_TEXT_SIZE = 18f;
    private static final float OTHER_TEXT_SIZE = 18f;
    private static final float LINE_SPACING = 40f; // Horizontal spacing between lines
    
    public HorizontalLyricsView(Context context) {
        super(context);
        init();
    }
    
    public HorizontalLyricsView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }
    
    private void init() {
        currentPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        currentPaint.setColor(0xFFFFFFFF); // White for current line
        currentPaint.setTextSize(CURRENT_TEXT_SIZE * getResources().getDisplayMetrics().density);
        
        otherPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        otherPaint.setColor(0xFFAAAAAA); // Gray for other lines
        otherPaint.setTextSize(OTHER_TEXT_SIZE * getResources().getDisplayMetrics().density);
    }
    
    /**
     * Load lyrics from .lrc file or ID3 tag
     */
    /**
     * Load lyrics from file (helper method for background loading)
     */
    public List<LyricLine> loadLyrics(File audioFile) {
        List<LyricLine> loadedLyrics = new ArrayList<>();
        if (audioFile == null || !audioFile.exists()) {
            return loadedLyrics;
        }

        // 1. Try .lrc file
        String audioPath = audioFile.getAbsolutePath();
        String lrcPath = audioPath.substring(0, audioPath.lastIndexOf(".")) + ".lrc";
        File lrcFile = new File(lrcPath);
        
        if (lrcFile.exists() && lrcFile.canRead()) {
            loadFromLrcFile(lrcFile, loadedLyrics);
        } else {
            // 2. Try ID3 tags (only if lrc not found)
            loadFromId3Tag(audioFile, loadedLyrics);
        }
        
        return loadedLyrics;
    }

    /**
     * Set lyrics directly (called from UI thread after background loading)
     */
    public void setLyrics(List<LyricLine> newLyrics) {
        this.lyrics = newLyrics != null ? newLyrics : new ArrayList<>();
        this.currentLineIndex = 0;
        requestLayout();
        invalidate();
    }

    public void setLyricsFromMedia(File audioFile) {
        // This method is kept for compatibility but should be avoided in main thread
        setLyrics(loadLyrics(audioFile));
    }
    
    private void loadFromLrcFile(File lrcFile, List<LyricLine> targetList) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(lrcFile));
            String line;
            // Fixed regex: [^\\[] means "match any character except ["
            // This prevents matching subsequent time tags
            Pattern pattern = Pattern.compile("\\[(\\d+):(\\d+\\.\\d+)\\]([^\\[]*)");
            
            while ((line = reader.readLine()) != null) {
                Matcher matcher = pattern.matcher(line);
                
                // Find all time tags in this line
                while (matcher.find()) {
                    int minutes = Integer.parseInt(matcher.group(1));
                    float seconds = Float.parseFloat(matcher.group(2));
                    String text = matcher.group(3).trim();
                    
                    if (!text.isEmpty()) {
                        long timeMs = (long) ((minutes * 60 + seconds) * 1000);
                        targetList.add(new LyricLine(timeMs, text));
                        
                        // Debug log
                        // android.util.Log.d("HorizontalLyrics", "Loaded: [" + timeMs + "ms] " + text);
                    }
                }
            }
            reader.close();
            
            Collections.sort(targetList, (a, b) -> Long.compare(a.time, b.time));
            
            // Debug: Show total lyrics loaded
            // android.util.Log.d("HorizontalLyrics", "Total lyrics loaded: " + targetList.size());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void loadFromId3Tag(File audioFile, List<LyricLine> targetList) {
        try {
            // android.util.Log.d("HorizontalLyrics", "尝试从 ID3 标签读取歌词...");
            org.jaudiotagger.audio.AudioFile af = org.jaudiotagger.audio.AudioFileIO.read(audioFile);
            org.jaudiotagger.tag.Tag tag = af.getTag();
            
            if (tag != null) {
                String lyricsText = tag.getFirst(org.jaudiotagger.tag.FieldKey.LYRICS);
                if (lyricsText != null && !lyricsText.trim().isEmpty()) {
                    // android.util.Log.d("HorizontalLyrics", "找到 ID3 歌词，长度: " + lyricsText.length());
                    // Split lines and parse each line using regex
                    String[] lines = lyricsText.split("\n");
                    // Support both [mm:ss.xx] and [mm:ss]
                    Pattern pattern = Pattern.compile("\\[(\\d+):(\\d+(?:\\.\\d+)?)\\]([^\\[]*)");
                    
                    for (String line : lines) {
                        Matcher matcher = pattern.matcher(line);
                        
                        while (matcher.find()) {
                            try {
                                int minutes = Integer.parseInt(matcher.group(1));
                                float seconds = Float.parseFloat(matcher.group(2));
                                String text = matcher.group(3).trim();
                                
                                long timeMs = (long) ((minutes * 60 + seconds) * 1000);
                                if (!text.isEmpty()) {
                                    targetList.add(new LyricLine(timeMs, text));
                                }
                            } catch (NumberFormatException e) {
                                // Ignore malformed numbers
                            }
                        }
                    }
                    
                    Collections.sort(targetList, (a, b) -> Long.compare(a.time, b.time));
                    // android.util.Log.d("HorizontalLyrics", "成功解析 " + targetList.size() + " 行歌词");
                } else {
                    // android.util.Log.d("HorizontalLyrics", "ID3 标签中没有歌词");
                }
            } else {
                // android.util.Log.d("HorizontalLyrics", "ID3 标签为 null");
            }
        } catch (Throwable e) {
            // android.util.Log.e("HorizontalLyrics", "读取 ID3 歌词失败: " + e.getMessage());
            // e.printStackTrace();
        }
    }
    
    /**
     * Update current playback time
     */
    public void updateTime(long timeMs) {
        currentTime = timeMs;
        
        // Find current line
        int newIndex = -1;
        for (int i = 0; i < lyrics.size(); i++) {
            if (lyrics.get(i).time <= currentTime) {
                newIndex = i;
            } else {
                break;
            }
        }
        
        if (newIndex != currentLineIndex) {
            currentLineIndex = newIndex;
            
            // Debug log when lyrics change
            if (newIndex >= 0 && newIndex < lyrics.size()) {
                android.util.Log.d("HorizontalLyrics", "Time: " + timeMs + "ms, Switch to line " + newIndex + ": " + lyrics.get(newIndex).text);
            }
            
            invalidate();
        }
    }
    
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        
        if (lyrics.isEmpty()) {
            // Show "No lyrics"
            otherPaint.setTextSize(14 * getResources().getDisplayMetrics().density);
            // Center the "No Lyrics" text
            float textWidth = otherPaint.measureText("歌词：暂无歌词");
            canvas.drawText("歌词：暂无歌词", (getWidth() - textWidth) / 2f, getHeight() / 2f, otherPaint);
            return;
        }
        
        float y = getHeight() / 2f + 5; // Vertical center position
        
        // Determine which line to focus on. If index is -1 (start), focus on the first line (0)
        int focusIndex = Math.max(0, currentLineIndex);
        if (focusIndex >= lyrics.size()) focusIndex = lyrics.size() - 1;

        // Calculate the width of all lines before the current one to determine offset
        float widthBeforeCurrent = 0;
        for (int i = 0; i < focusIndex; i++) {
            LyricLine lyric = lyrics.get(i);
            // Non-focused lines are drawn with otherPaint
            widthBeforeCurrent += otherPaint.measureText(lyric.text) + LINE_SPACING;
        }
        
        // Calculate width of current line
        float currentLineWidth = currentPaint.measureText(lyrics.get(focusIndex).text);
        
        // We want the center of the current line to be at getWidth() / 2
        // Position of center of current line = startX + widthBeforeCurrent + currentLineWidth / 2
        // So: getWidth() / 2 = startX + widthBeforeCurrent + currentLineWidth / 2
        // startX = getWidth() / 2 - widthBeforeCurrent - currentLineWidth / 2
        
        float startX = (getWidth() / 2f) - widthBeforeCurrent - (currentLineWidth / 2f);
        
        // Draw all lyrics horizontally
        float x = startX;
        for (int i = 0; i < lyrics.size(); i++) {
            LyricLine lyric = lyrics.get(i);
            Paint paint = (i == currentLineIndex) ? currentPaint : otherPaint;
            float lineWidth = paint.measureText(lyric.text);
            
            // Optimization: Only draw if within visible bounds (with some buffer)
            if (x + lineWidth > 0 && x < getWidth()) {
                canvas.drawText(lyric.text, x, y, paint);
            }
            
            x += lineWidth + LINE_SPACING;
        }
    }
    
    public static class LyricLine {
        public long time;
        public String text;
        
        public LyricLine(long time, String text) {
            this.time = time;
            this.text = text;
        }
    }
}
